# GameOfLife

This program is build to demonstrate Conway's game of life. 
The game has several specific rules that create patterns, based on which cells are alive and which are dead.
Although the rules in Conway's game of life are very specific this program will give the user the option to experiment
with these rules. 
It is possible to change the set of rules to investigate what happens when the rules are slightly changed.
<br/>
<br/>
To run the game use pygol.gameoflife.rungame()


